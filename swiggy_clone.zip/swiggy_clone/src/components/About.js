import User from "./User";
import UserClass from "./UserClass";

const About=()=>{
    <div></div>

    return(

         <div>
            <h1> well come to about page</h1>
            <User name ={"vamshhi"}/>
            <UserClass name={"ajay"}/>
        </div>
        

    );

};
 export default About;