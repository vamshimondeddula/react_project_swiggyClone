
export const CDN_URL =
  'https://media-assets.swiggy.com/swiggy/image/upload/';

export const LOGO_URL=
"https://png.pngtree.com/png-vector/20230217/ourmid/pngtree-food-logo-design-for-restaurant-and-business-png-image_6604922.png";

export const MENU_API="https://www.swiggy.com/mapi/menu/pl?page-type=REGULAR_MENU&complete-menu=true&lat=17.406498&lng=78.47724389999999&restaurantId=";
